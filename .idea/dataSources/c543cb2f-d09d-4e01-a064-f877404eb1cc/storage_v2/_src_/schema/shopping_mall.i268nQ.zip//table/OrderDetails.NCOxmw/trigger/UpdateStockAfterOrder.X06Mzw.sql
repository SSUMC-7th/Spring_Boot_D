create definer = root@localhost trigger UpdateStockAfterOrder
    after update
    on OrderDetails
    for each row
BEGIN
    UPDATE Product
    SET stock = stock - NEW.quantity
    WHERE Product.product_id = NEW.product_id;
END;

