create definer = root@localhost view customerorders as
select `shopping_mall`.`customer`.`name`         AS `name`,
       `shopping_mall`.`ordertable`.`order_id`   AS `order_id`,
       `shopping_mall`.`ordertable`.`order_date` AS `order_date`
from (`shopping_mall`.`customer` join `shopping_mall`.`ordertable`
      on ((`shopping_mall`.`customer`.`customer_id` = `shopping_mall`.`ordertable`.`customer_id`)));

